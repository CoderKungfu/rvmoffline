
Usage

  rvm reinstall [ruby-string]

It is equivalent to:

  rvm remove  [ruby-string]
  rvm install [ruby-string]

Please see the documentation for further information:

  https://rvm.io/rubies/installing/
